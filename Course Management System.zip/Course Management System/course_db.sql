CREATE DATABASE course_db;

USE course_db;

CREATE TABLE courses (
course_id INT PRIMARY KEY AUTO_INCREMENT,
course_name VARCHAR(100) NOT NULL,
instructor VARCHAR(100) NOT NULL,
duration VARCHAR(50) NOT NULL
);
