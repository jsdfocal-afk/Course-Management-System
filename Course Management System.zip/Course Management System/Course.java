public class Course {

    private int courseId;
    private String courseName;
    private String instructor;
    private String duration;

    public Course(int courseId,
                  String courseName,
                  String instructor,
                  String duration) {

        this.courseId = courseId;
        this.courseName = courseName;
        this.instructor = instructor;
        this.duration = duration;
    }

    public int getCourseId() {
        return courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public String getInstructor() {
        return instructor;
    }

    public String getDuration() {
        return duration;
    }
}