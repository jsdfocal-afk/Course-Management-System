import java.sql.*;
import java.util.Scanner;

public class CourseManagement {

    static Scanner sc = new Scanner(System.in);

    public static void addCourse() {

        try {
            Connection con =
                    DBConnection.getConnection();

            System.out.print("Course Name: ");
            String name = sc.nextLine();

            System.out.print("Instructor: ");
            String instructor = sc.nextLine();

            System.out.print("Duration: ");
            String duration = sc.nextLine();

            PreparedStatement ps =
                    con.prepareStatement(
                            "INSERT INTO courses(course_name,instructor,duration) VALUES(?,?,?)");

            ps.setString(1, name);
            ps.setString(2, instructor);
            ps.setString(3, duration);

            ps.executeUpdate();

            System.out.println("Course Added Successfully");

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void viewCourses() {

        try {
            Connection con =
                    DBConnection.getConnection();

            Statement st =
                    con.createStatement();

            ResultSet rs =
                    st.executeQuery("SELECT * FROM courses");

            System.out.println("\n--- COURSE LIST ---");

            while (rs.next()) {

                System.out.println(
                        rs.getInt("course_id")
                        + " | "
                        + rs.getString("course_name")
                        + " | "
                        + rs.getString("instructor")
                        + " | "
                        + rs.getString("duration"));
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void deleteCourse() {

        try {
            Connection con =
                    DBConnection.getConnection();

            System.out.print("Enter Course ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            PreparedStatement ps =
                    con.prepareStatement(
                            "DELETE FROM courses WHERE course_id=?");

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0)
                System.out.println("Course Deleted");
            else
                System.out.println("Course Not Found");

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        while (true) {

            System.out.println("\n===== COURSE MANAGEMENT SYSTEM =====");
            System.out.println("1. Add Course");
            System.out.println("2. View Courses");
            System.out.println("3. Delete Course");
            System.out.println("4. Exit");

            System.out.print("Enter Choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:
                    addCourse();
                    break;

                case 2:
                    viewCourses();
                    break;

                case 3:
                    deleteCourse();
                    break;

                case 4:
                    System.out.println("Thank You!");
                    System.exit(0);

                default:
                    System.out.println("Invalid Choice");
            }
        }
    }
}